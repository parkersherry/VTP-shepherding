import scipy
import numpy as np
import shapely
def LDOD(X,r):
    DOD = 0
    N = np.size(X,0)

    toAppend = np.array([[10**6,10**6],[-10**6,10**6],[10**6,-10**6],[-10**6,-10**6]])
    X = np.concatenate((X.T,toAppend.T),axis=1).T

    vor = scipy.spatial.Voronoi(X)
    C = [vor.regions[reg] for reg in vor.point_region]
    V = vor.vertices

    n=100
    theta = np.linspace(0,2*np.pi,n)
    for i in range(N):
        ce = C[i]
        verts = V[ce,:]
        vRegion = shapely.Polygon(verts)

        cx,cy = X[i,0],X[i,1]
        x = cx + r*np.cos(theta)
        y = cy + r*np.sin(theta)

        c = np.column_stack((x,y))
        circ = shapely.Polygon(c)

        limited = shapely.intersection(circ,vRegion)
        A = shapely.area(limited)
        DOD = DOD + A
    DOD = DOD/(N*np.pi*r*r)
    return DOD



