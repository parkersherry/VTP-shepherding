import numpy as np
# import cupy as np
from scipy.spatial import Voronoi
from shapely.geometry import Polygon


def LDOD_gpu(X, r):
    """
    Compute local density overlap degree (LDOD) using GPU for circle coordinates.
    Note: Voronoi and shapely still run on CPU, but circle creation is vectorized.
    """
    DOD = 0
    N = X.shape[0]


    # Append extreme points to avoid infinite Voronoi regions
    toAppend = np.array([[1e6,1e6],[-1e6,1e6],[1e6,-1e6],[-1e6,-1e6]])
    X_aug = np.vstack((X, toAppend))


    # Compute Voronoi
    vor = Voronoi(X_aug)
    regions = [vor.regions[reg] for reg in vor.point_region[:N]]  # only first N points
    vertices = vor.vertices


    # Precompute circle coordinates on GPU
    n = 100
    theta = np.linspace(0, 2*np.pi, n)
    circle_coords = np.stack((r*np.cos(theta), r*np.sin(theta)), axis=1)  # shape (n,2)


    for i in range(N):
        region_idx = regions[i]
        # if -1 in region_idx:  # skip infinite regions
        #     continue
        verts = vertices[region_idx, :]
        vRegion = Polygon(verts)


        cx, cy = X[i]
        c = (circle_coords + np.array([cx, cy]))  # shift circle to center
        circ = Polygon(c)


        limited = circ.intersection(vRegion)
        A = limited.area
        DOD += A


    DOD /= (N * np.pi * r**2)
    return DOD
