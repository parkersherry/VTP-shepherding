import numpy as np
import shapely


class Target:

    def __init__(self, C,ids=None):
        self.emptiness = False
        if type(C) == np.float16:
            C = np.array([C])
        elif type(C)==list:
            if len(C) == 0:
                self.Components = []
                self.Ids = []
                self.emptiness = True
            k = len(C)
            K = [None]*k
            for m in range(k):
                P = (C[m])
                if np.size(P) < 6:
                    K[m] = shapely.points(P)
                    continue
                pgon = shapely.Polygon(P)
                K[m] = pgon
            self.Components = K
            self.Ids = ids
        else:
            if np.size(C) == 0:
                self.Components = []
                self.Ids = []
                self.emptiness = True
            P = C
            if np.size(P) < 6:
                K = shapely.points(P)
            else:
                pgon = shapely.Polygon(P)
                K = pgon
            self.Components = [K]
            self.Ids = ids


def homeToTarget(tar: Target, X, target_idx=None, careIfInterior=False):
    N = int(np.size(X)/2)
    h = np.zeros((N, 2))
    def homeToPoint(pt:shapely.geometry.point.Point):
        ptNumpy = np.array([pt.x,pt.y])
        return ptNumpy - X
    def homeToLine(p1, p2):
        """
        Finds the closest point on a line (defined by p1 and p2) to a given point p0.

        Args:
            p0 (tuple): The given point (x0, y0).
            p1 (tuple): The first point defining the line (x1, y1).
            p2 (tuple): The second point defining the line (x2, y2).

        Returns:
            tuple: The coordinates of the closest point on the line.
        """
        x1, y1 = p1.x,p1.y
        x2, y2 = p2.x,p2.y

        # Vector representing the line segment (V)
        vx, vy = x2 - x1, y2 - y1

        # Vector from p1 to p0 (W)
        wx, wy = X[:,0] - x1, X[:,1] - y1

        # Squared magnitude of V
        len_sq = vx**2 + vy**2

        # Handle the case where p1 and p2 are the same point
        if len_sq == 0:
            return p1  # Or p2, they are the same

        # Calculate the scalar projection (t)
        t = (wx * vx + wy * vy) / len_sq

        # For an infinite line, no clamping is needed.
        # For a line segment, clamp t between 0 and 1:
        t[t>1]=1
        t[t<0]=0

        # Calculate the closest point
        closest_x = x1 + t * vx
        closest_y = y1 + t * vy
        onLine = np.stack((closest_x,closest_y))
        return onLine.T - X
    def homeToPolygon(polygon):
        points = shapely.points(X)
        if N ==1:
            points = [points]
        # Prepare the polygon for faster queries (optional but good for many points)

        closest_points_on_boundary = []
        for point in points:
            # Find the closest point on the polygon's boundary
            # This works for points inside or outside the polygon
            if careIfInterior:
                if polygon.contains(point):
                    closest_points_on_boundary.append(np.array([0, 0]))
                    continue
            closest_point = polygon.exterior.interpolate(polygon.exterior.project(point))
            closest_points_on_boundary.append(closest_point)
        # Convert closest points to a NumPy array for vectorized operations
        arr = [None]*len(closest_points_on_boundary)
        i=0
        for p in closest_points_on_boundary:
            arr[i] = np.array([p.x,p.y])
            i+=1
        closest_coords = np.array(arr)

        # Calculate the vectors
        vectors = closest_coords - X
        return vectors
    if not tar.Components:
        return np.zeros_like(X)
    normedVecs = np.zeros((int(np.size(X)/2),len(tar.Components)))
    arrOfVecs = np.zeros((int(np.size(X)/2),2,len(tar.Components)))
    for i,component in enumerate(tar.Components):
        vecs = None
        if type(component) == np.ndarray:
            if len(component)==2:
                p1 = component[0]
                p2 = component[1]
                vecs = homeToLine(p1,p2)
            if len(component)==1:
                p = component[0]
                vecs = homeToPoint(p)
        elif type(component) == shapely.geometry.point.Point:
            p = component
            vecs = homeToPoint(p)
        elif type(component)== shapely.geometry.polygon.Polygon:
            poly = component
            vecs = homeToPolygon(poly)
        else:
            s = str(type(component))
            print("Component has type " + s)
            raise TypeError
        if np.size(vecs)==2:
            normedVecs[:,i] = np.linalg.norm(vecs)
        else:
            normedVecs[:,i] = np.linalg.norm(vecs,axis=1)
        arrOfVecs[:,:,i] = vecs
    indices = np.argmin(normedVecs,axis=1)
    return arrOfVecs[:,:,indices].T[0].T
