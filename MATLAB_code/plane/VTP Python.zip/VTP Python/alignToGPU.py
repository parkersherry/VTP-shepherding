import numpy as np
import scipy
import transition
def alignTo(X,U,nbhd,transition_func,sheepThetaVision,Ndogs,vMaxSheep):
    N = np.size(U[:,1])
    a = np.zeros_like(X)

    def trans(x):
        return transition.transition(x,transition_func)
    f = np.vectorize(trans)

    Unorms = np.linalg.norm(U, 2, 1)
    Unorms = Unorms.reshape(-1, 1)
    with np.errstate(divide='ignore', invalid='ignore'):
        normalizedUVec = U/Unorms
        normalizedUVec = np.nan_to_num(normalizedUVec)  # replace NaNs with 0

    normalizedUVec[np.isnan(normalizedUVec)] = 0

    for i in range(Ndogs,N):
        dots = np.matmul(normalizedUVec[nbhd[i],:],normalizedUVec[i,:]) # for some i, nbhd[i] is empty?
        dots[dots > 1] = 1
        dots[dots < -1] = -1


        separation = X[nbhd[i],:]-X[i,:]
        sepnorm = np.linalg.norm(separation,2,axis=1)
        sepnorm = sepnorm.reshape(-1, 1)
        separationNormed = separation/sepnorm

        FOV = np.arccos(np.dot(separationNormed,normalizedUVec[i]))
        FOV[FOV > sheepThetaVision[i]/2] = 0
        FOV[FOV <= sheepThetaVision[i]/2] = 1

        thetaNormed = np.arccos(dots)/np.pi

        ##APPLY TRANSITION FUNCTION
        thetaTransformed = f(thetaNormed)
        a[i,:] = np.sum((FOV * thetaTransformed)[:, None] * normalizedUVec[nbhd[i]], axis=0)

    return (1/6)*a