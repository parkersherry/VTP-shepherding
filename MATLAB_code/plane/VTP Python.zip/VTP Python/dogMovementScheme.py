import numpy as np
import scipy.spatial
# The following modules are assumed to exist in your codebase.
import neighborhoods
import Target
import getSubflocks
import transition
import findDogEquil


def dogMovementScheme(X_T, U, DT, Ndogs, L, tar, t, dt, LastSeen, Xmem, memDuration,allnbhd,nearest):
    """
    Fixed / shape-robust version of your function.

    Expected shapes:
    - X_T: (N,2,T)
    - U: (N,2)
    - LastSeen: (N,)
    - Xmem: (N,2)
    - returns: (U, goalLocationArr, P, LastSeen, Xmem, expDecay_out, stopSimul, subflockCells)
    """

    stopSimul = False

    # snapshot at time t (assumes t is 0-based index into third axis)
    X = X_T[:, :, t].copy()
    N_total = X.shape[0]    # total agents (dogs + sheep)
    Xsheep = X[Ndogs:, :]   # sheep positions only

    recallDelay = memDuration

    # neighborhoods.neighborhood may return tuple with multiple types.
    # We try to be robust and find nearest array inside return value.
    res = neighborhoods.neighborhood(DT, 2)
    # assume first element is nbhd
    # nbhd = res[0]
    # nearest = None
    # try to find a 1-D numeric array in the returned tuple (closest to "nearest")
    # for item in res:
    #     try:
    #         arr = np.asarray(item)
    #         if arr.ndim == 1 and arr.size == N_total:
    #             nearest = arr
    #             break
    #     except Exception:
    #         continue
    # # fallback if not found
    # if nearest is None:
    #     # try common unpacking pattern (in case res is (nbhd, nearest, extra))
    #     if len(res) >= 2:
    #         try:
    #             nearest = np.asarray(res[1])
    #         except Exception:
    #             nearest = np.full((N_total,), -1, dtype=int)
    #     else:
    #         nearest = np.full((N_total,), -1, dtype=int)

    # Convex hull of sheep positions (use Xsheep). Guard degenerate cases.
    if Xsheep.shape[0] >= 3:
        hull = scipy.spatial.ConvexHull(Xsheep)
        k_output = hull.vertices  # indices into Xsheep
        indicesConvHull = np.append(k_output, k_output[0])  # closed polygon index list
        ConvHullTarget = Target.Target(Xsheep[indicesConvHull, :])
    else:
        # degenerate case: use all sheep or an empty target handled by Target.Target
        ConvHullTarget = Target.Target(Xsheep)

    # Containers
    CMs = np.zeros((Ndogs, 2))
    SheepToCollectArr = -1 * np.ones((Ndogs,), dtype=int)
    sheepIsSeen = np.ones((Ndogs,), dtype=int)
    DogDisplacementVec = np.zeros((Ndogs, 2))
    goalLocationArr = np.zeros_like(DogDisplacementVec)

    decayRate = recallDelay * 0.02
    ExpAmplitude = 0.43
    ExpShift = 0.48

    # placeholder outputs
    P = None
    SubflockCells = [Xsheep.copy()]

    # time threshold (use absolute time)
    timeThreshold = max(0.0, t * dt - recallDelay)

    for i in range(Ndogs):
        # Sheep seen recently (1D index array)
        # LastSeen is expected to be 1-D array, shape (N_total,)
        LastSeen = np.asarray(LastSeen).ravel()
        SheepNbhdPast = np.where(LastSeen > timeThreshold)[0]
        forgotten = np.where((LastSeen <= timeThreshold) & (LastSeen != 0))[0]

        # current neighborhood for dog i
        # nbhd[i] expected to be something like (list1, list2)
        # try:
        #     neigh1, neigh2 = nbhd[i]
        # except Exception:
        #     # fallback: if nbhd[i] is a single iterable, treat it as neigh1 and empty neigh2
        #     item = nbhd[i]
        #     try:
        #         neigh1 = np.asarray(item).ravel()
        #     except Exception:
        #         neigh1 = np.array([], dtype=int)
        #     neigh2 = np.array([], dtype=int)
        #
        # currAllNbhd = np.unique(np.concatenate([np.asarray(neigh1, dtype=int),
        #                                         np.asarray(neigh2, dtype=int)])) if (len(neigh1) or len(neigh2)) else np.array([], dtype=int)
        currAllNbhd = allnbhd[i]
        # remove any 'forgotten' indices that are in current neighborhood
        if forgotten.size > 0 and currAllNbhd.size > 0:
            forgotten = np.setdiff1d(forgotten, currAllNbhd)

        # sheep indices in current neighborhood (global indices)
        currSheepNbhd = currAllNbhd[currAllNbhd >= Ndogs]  # global indices for sheep

        # Update memory for sheep seen now (X and Xmem are shape (N_total,2))
        if np.size(currSheepNbhd) > 0:
            Xmem[currSheepNbhd, :] = X[currSheepNbhd, :]
            LastSeen[currSheepNbhd] = t * dt

        # union of past seen sheep and current seen sheep
        SheepNbhd = np.unique(np.union1d(currSheepNbhd, SheepNbhdPast))

        # forget the ones flagged as forgotten
        if forgotten.size > 0:
            Xmem[forgotten, :] = 0.0
            LastSeen[forgotten] = 0.0

        # remove sheep whose memory is all zeros
        if np.size(SheepNbhd) > 0:
            nonzero_mask = ~np.all(Xmem[SheepNbhd, :] == 0.0, axis=1)
            SheepNbhd = SheepNbhd[nonzero_mask]
        elif np.size(SheepNbhd) == 0:
            # this dog sees no sheep
            sheepIsSeen[i] = 0
            continue

        # exponential decay per sheep
        LastSeen_sub = LastSeen[SheepNbhd]
        exponentialDecay_scalar = ExpAmplitude * np.exp(decayRate * (LastSeen_sub - t * dt) / recallDelay) + ExpShift

        # weighted center of mass (CM)
        sumExpDecay = np.sum(exponentialDecay_scalar)
        if sumExpDecay == 0:
            CM = np.mean(Xmem[SheepNbhd, :], axis=0)
        else:
            CM = np.sum(Xmem[SheepNbhd, :] * exponentialDecay_scalar[:, None], axis=0) / sumExpDecay

        # find the sheep which maximizes the angle (sheep to collect)
        xDog = X[i, :].copy()               # shape (2,)
        xDog = np.asarray(xDog).reshape(2,)

        CMtoDog = xDog - CM                # (2,)
        CMtoDogNorm = np.linalg.norm(CMtoDog)
        CMtoDog_unit = CMtoDog / CMtoDogNorm if CMtoDogNorm != 0 else CMtoDog

        # DogToSheep: vectors from each sheep (in memory) toward the dog => shape (k,2)
        DogToSheep = xDog - Xmem[SheepNbhd, :]   # broadcasting works: (2,) - (k,2) -> (k,2)
        # ensure it's 2-D
        DogToSheep = np.atleast_2d(DogToSheep)
        DogToSheepNorm = np.linalg.norm(DogToSheep, axis=1)
        DogToSheep_unit = np.copy(DogToSheep)
        nonzero_mask = DogToSheepNorm != 0
        if np.any(nonzero_mask):
            DogToSheep_unit[nonzero_mask, :] = DogToSheep[nonzero_mask, :] / DogToSheepNorm[nonzero_mask, None]

        # clip dot product for numeric stability
        # CMtoDog_unit shape (2,), DogToSheep_unit shape (k,2) -> dot yields (k,)
        dots = DogToSheep_unit.dot(CMtoDog_unit)
        dots = np.clip(dots, -1.0, 1.0)
        thetaArr = np.arccos(dots)  # shape (k,)

        # don't target sheep already targeted by other dogs
        if np.any(SheepToCollectArr >= 0):
            inter_mask = np.isin(SheepNbhd, SheepToCollectArr)
            if inter_mask.size == thetaArr.size:
                thetaArr[inter_mask] = 0.0
            else:
                # safe guard - map positions
                idxs = np.where(inter_mask)[0]
                if idxs.size > 0:
                    thetaArr[idxs] = 0.0

        # select sheep maximizing theta
        ind = int(np.argmax(thetaArr))
        SheepToCollect = int(SheepNbhd[ind])
        SheepToCollectArr[i] = SheepToCollect

        # repel from convex hull (Target.homeToTarget should return vector(s))
        h = Target.homeToTarget(ConvHullTarget, xDog, 1, False)
        h = np.asarray(h)
        # flatten to 1D if single vector
        if h.ndim > 1:
            # if shape (1,2) -> reshape to (2,)
            h = h.reshape(-1)
        distToConvHull = np.linalg.norm(h)
        h_unit = (h / distToConvHull) if distToConvHull != 0 else h

        # compute goal location
        XsheepToCollect = Xmem[SheepToCollect, :]
        goalLocation = XsheepToCollect - CM
        goalLocationNorm = np.linalg.norm(goalLocation)
        if goalLocationNorm != 0:
            goalLocation = (goalLocation / goalLocationNorm) * L
        goalLocation = goalLocation + XsheepToCollect
        dogToGoal = goalLocation - xDog
        dogToGoalNorm = np.linalg.norm(dogToGoal)
        dogToGoal_unit = dogToGoal / dogToGoalNorm if dogToGoalNorm != 0 else dogToGoal

        # direction from CM to dog relative to target
        CMtoDogTar = Target.homeToTarget(tar, CM)
        CMtoDogTar = np.asarray(CMtoDogTar).reshape(-1)
        CMtoDogTarNorm = np.linalg.norm(CMtoDogTar)
        CMtoDogTar_unit = CMtoDogTar / CMtoDogTarNorm if CMtoDogTarNorm != 0 else CMtoDogTar

        dot_CD = np.clip(np.dot(CMtoDog_unit, CMtoDogTar_unit), -1.0, 1.0)
        thetaDogEquil = np.arccos(dot_CD)

        # equilibrium from helper: only compute if target is non-empty (Target sets .emptiness flag)
        if not getattr(tar, "emptiness", False):
            # pass relevant arguments; findDogEquil should return (2,) array or similar
            equilibrium = findDogEquil.findDogEquil(CM, L, tar, np.size(SheepNbhd))
            # guard None
            if equilibrium is None:
                DogToEquil = np.zeros_like(xDog)
            else:
                equilibrium = np.asarray(equilibrium).reshape(-1)
                DogToEquil = equilibrium - xDog
        else:
            equilibrium = None
            DogToEquil = np.zeros_like(xDog)

        DogToEquil = np.asarray(DogToEquil).reshape(-1)
        DogToEquilNorm = np.linalg.norm(DogToEquil)
        DogToEquil_unit = DogToEquil / DogToEquilNorm if DogToEquilNorm != 0 else DogToEquil

        # driving & repel scalars
        sDriving = 0.0 if getattr(tar, "emptiness", False) else transition.transition(thetaDogEquil / np.pi, 'expReciprocal')
        s = transition.transition(distToConvHull / L, 'expReciprocal')

        # nearest: ensure integer index and valid
        try:
            nearestIndex_raw = nearest[i]
            nearestIndex = int(np.asarray(nearestIndex_raw).item())
        except Exception:
            nearestIndex = -1

        if (nearestIndex < 0) or (nearestIndex >= N_total):
            # no valid neighbor: set repel vector to zero
            dogNearestRepel_unit = np.zeros((2,))
            dogNearestRepelNorm = 0.0
            dogS = 0.0
        else:
            dogNearestRepel = xDog - X[nearestIndex, :]
            dogNearestRepel = np.asarray(dogNearestRepel).reshape(-1)
            dogNearestRepelNorm = np.linalg.norm(dogNearestRepel)
            dogNearestRepel_unit = dogNearestRepel / dogNearestRepelNorm if dogNearestRepelNorm != 0 else dogNearestRepel
            dogS = transition.transition(dogNearestRepelNorm / L, 'expReciprocal')

        # combine to produce displacement: ensure both sides are 1D shape (2,)
        part1 = (1 - sDriving) * (1 - dogS) * dogToGoal_unit
        part2 = DogToEquil_unit * sDriving
        repel_part = dogS * dogNearestRepel_unit - s * h_unit
        # ensure repel_part is 1D
        repel_part = np.asarray(repel_part).reshape(2,)

        DogDisplacementVec[i, :] = np.asarray(part1).reshape(2,) + np.asarray(part2).reshape(2,)
        DogDisplacementVec[i, :] += repel_part

        goalLocationArr[i, :] = goalLocation
        CMs[i, :] = CM

    # after loop
    if np.max(sheepIsSeen) == 0:
        stopSimul = True

    W = DogDisplacementVec.copy()
    g = np.ones((Ndogs,), dtype=float)
    norms_W = np.linalg.norm(W, axis=1)
    tooLarge_idx = np.where(norms_W > 1.0)[0]
    if tooLarge_idx.size > 0:
        g[tooLarge_idx] = 1.0 / norms_W[tooLarge_idx]
    W = (g[:, None] * W)

    # For dogs that saw no sheep, set their velocity to the mean dog's velocity
    toReplace = np.where(sheepIsSeen == 0)[0]
    if toReplace.size != 0:
        meanDogsVel = np.mean(W, axis=0)
        W[toReplace, :] = meanDogsVel

    U[:Ndogs, :] = W

    # exponentialDecay (return last computed scalar array per loop if exists)
    try:
        expDecay_out = exponentialDecay_scalar.copy()
    except NameError:
        expDecay_out = np.array([])

    subflockCells = SubflockCells

    return U, goalLocationArr, P, LastSeen, Xmem, expDecay_out, stopSimul, subflockCells
