import numpy as np
import Target
def findDogEquil(CM,L,tar,NumSheepNbhd):
    R = -1*np.sqrt(NumSheepNbhd)*L
    V = Target.homeToTarget(tar,CM)
    Vnormed = np.linalg.norm(V,2)
    if Vnormed!=0:
        V = V/Vnormed
    V = V*R
    V = V + CM
    return V