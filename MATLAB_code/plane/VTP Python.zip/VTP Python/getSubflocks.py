def getSubflocks(X,XAtCurrSheepnbhd,dogL,N,Ndogs,subflocks,DT_on):
    return subflocks