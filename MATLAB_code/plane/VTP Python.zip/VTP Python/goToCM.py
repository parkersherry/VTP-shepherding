import numpy as np
import transition

def goToCM(X, Firstnbhd, N, Ndogs, trans_func, LArr, L, cutoff=None):
    if cutoff is None:
        cutoff = 1000 * L

    G = np.zeros_like(X)
    FirstSheepNbhd = []
    for nb in Firstnbhd:
        FirstSheepNbhd.append(nb[nb>=Ndogs])
    for i in range(N):
        if i < Ndogs:  # skip dogs
            continue

        # Only consider sheep neighbors

        if len(FirstSheepNbhd[i]) == 0:
            continue

        Xnbhd = X[FirstSheepNbhd[i], :]
        distForCutoff = np.linalg.norm(Xnbhd - X[i,:], axis=1)
        # Keep only neighbors within cutoff
        within_cutoff = distForCutoff < cutoff
        XCutoff = Xnbhd[within_cutoff, :]
        if XCutoff.shape[0] == 0:
            continue

        CM = np.mean(XCutoff, axis=0)
        G[i, :] = CM - X[i, :]

    Gnormed = np.linalg.norm(G, axis=1)
    s = np.array([transition.transition(g/LArr[i], trans_func) for i, g in enumerate(Gnormed)])

    # Avoid division by zero
    with np.errstate(divide='ignore', invalid='ignore'):
        G = (s[:, np.newaxis] * G) / Gnormed[:, np.newaxis]
        G[np.isnan(G)] = 0

    return G