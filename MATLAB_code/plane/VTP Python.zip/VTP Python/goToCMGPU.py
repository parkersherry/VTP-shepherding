import numpy as np
import transition  # assuming transition.transition works on CPU; we'll vectorize it after
def goToCM(X, Firstnbhd, N, Ndogs, trans_func, LArr, L, cutoff=None):
    if cutoff is None:
        cutoff = 1000 * L

    X = np.asarray(X)
    LArr = np.asarray(LArr)

    # Prepare sheep neighborhoods as boolean mask

    mask_list = []
    max_neighbors = max(len(nb[nb >= Ndogs]) for nb in Firstnbhd)
    FirstSheepNbhd_array = np.full((N, max_neighbors), -1, dtype=np.int32)

    ##TODO: Can this for loop be vectorized using awkward indexing

    for i, nb in enumerate(Firstnbhd):
        sheep_nb = nb[nb >= Ndogs]
        FirstSheepNbhd_array[i, :len(sheep_nb)] = np.asarray(sheep_nb, dtype=np.int32)

    # Create mask to ignore padding (-1)
    valid_mask = FirstSheepNbhd_array >= 0

    # Gather all neighbors
    nb_indices = np.where(valid_mask, FirstSheepNbhd_array, 0)  # safe indexing
    Xnbhd = X[nb_indices]  # shape (N, max_neighbors, dim)

    # Compute distances to neighbors
    Xi = X[:, np.newaxis, :]  # shape (N, 1, dim)
    diff = Xnbhd - Xi  # shape (N, max_neighbors, dim)
    dist = np.linalg.norm(diff, axis=2)
    dist = np.where(valid_mask, dist, cutoff + 1)  # mask out invalid neighbors

    # Apply cutoff
    within_cutoff = dist < cutoff
    # Avoid empty neighbor sets by setting masked distances to 0
    weights = np.where(within_cutoff, 1, 0)
    G = np.sum(diff * weights[:, :, np.newaxis], axis=1)
    counts = np.sum(weights, axis=1, keepdims=True)
    counts = np.where(counts == 0, 1, counts)  # avoid div by zero
    G = G / counts  # mean vector to CM

    # Normalize and scale by transition function
    Gnormed = np.linalg.norm(G, axis=1)

    # transition.transition likely only works on CPU arrays; vectorize via list comprehension
    def fun(x):
        return transition.transition(x,trans_func)
    vecFun = np.vectorize(fun)
    s = vecFun(Gnormed/LArr)
    with np.errstate(divide='ignore', invalid='ignore'):
        G = (s[:, np.newaxis] * G) / Gnormed[:, np.newaxis]
        G = np.nan_to_num(G)  # replace NaNs with 0

    return G