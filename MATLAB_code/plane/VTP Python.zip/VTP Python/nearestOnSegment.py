import numpy as np
def lineDist(XA,XB,PA,PB,nA,nB):
    clPtA,clPtB = XA[PA,:],XB[PB,:]
    linePtA,linePtB = XA[nA,:],XB[nB,:]
    if clPtA[0] == linePtA[0] and clPtB[0] != linePtB[0]:
        mB = (clPtB[1] - linePtB[1])/(clPtB[0]-linePtB[0])
        interceptB = clPtB[1] - mB*clPtB[0]
        lineIntersect = np.array([clPtA[0],mB*clPtA[0]+interceptB])

        endPtsA = np.array([clPtA,linePtA])
        endPtsB = np.array([clPtB,linePtB])

        endPA = min(np.linalg.norm(lineIntersect - clPtA),np.linalg.norm(lineIntersect - linePtA))
        endPB = min(np.linalg.norm(lineIntersect - clPtB),np.linalg.norm(lineIntersect - linePtB))

        if ((endPtsA[0,1] > endPtsB[endPB,1] and endPtsB[endPB,1] > endPtsA[1,1]) or
            (endPtsA[0,1] < endPtsB[endPB,1] and endPtsB[endPB,1] < endPtsA[1,1])):
            D = np.abs(endPtsB[endPB,0] - endPtsA[0,0])
        else:
            D = np.abs(mB*endPtsA[endPA,0] - endPtsA[endPA,1]+interceptB)/np.sqrt(mB**2+1)

    elif clPtA[0]!=linePtA[0] and clPtB[0]==linePtB[0]:
        mA = (clPtA[1] - linePtA[1])/(clPtA[0] - linePtA[0])
        interceptA = clPtA[1] - mA*clPtA[0]
        lineIntersect = np.array([clPtB[0],mA*clPtB[0]+interceptA])

        endPtsA = np.array([clPtA,linePtA])
        endPtsB = np.array([clPtB,linePtB])

        endPA = min(np.linalg.norm(lineIntersect - clPtA), np.linalg.norm(lineIntersect-linePtA))
        endPB = min(np.linalg.norm(lineIntersect - clPtB), np.linalg.norm(lineIntersect-linePtB))

        if (((endPtsB[0,1] > endPtsA[endPA,1]) and (endPtsA[endPA,1]>endPtsB[1,1])) or
                ( (endPtsB[0,1] < endPtsA[endPA,1]) and (endPtsA[endPA,1]<endPtsB[1,1]))):
            D = np.abs(endPtsA[endPA,0] - endPtsB[0,0])
        else:
            D = np.abs(mA*endPtsB[endPB,0] - endPtsB[endPB,1] + interceptA)/np.sqrt(mA**2+1)

    elif clPtA[0] == linePtA[0] and clPtB[0] == linePtB[0]:
        lineArrA = np.sort(np.array([clPtA,linePtA]),0)
        lineArrB = np.sort(np.array([clPtB,linePtB]),0)

        y1 = lineArrA[0,1]
        y2 = linePtA[1,1]
        y3 = lineArrB[0,1]
        y4 = lineArrB[1,1]

        if (y1 <= y3 and y3 <= y2) or (y1 <= y4 and y4 <= y2) or (y3<=y1 and y2<=y4) or (y1<=y3 and y4<=y2):
            D = abs(clPtA[0] - clPtB[0])
        elif y1>y4:
            D = np.linalg.norm(lineArrA[0,:] - lineArrB[1,:])
        else:
            D = np.linalg.norm(lineArrA[1,:] - lineArrB[0,:])

    else:
        mA = (clPtA[1] - linePtA[1])/(clPtA[0] - linePtA[0])
        mB = (clPtB[1] - linePtB[1])/(clPtB[0] - linePtB[0])

        interceptA = clPtA[1] - mA*clPtA[0]
        interceptB = clPtB[1] - mB*clPtB[0]

        if mA == mB:
            tempVec = clPtA - linePtA
            theta = np.atan(tempVec[0]/tempVec[1])

            #make a rotation matrix
            R = np.array([[np.cos(theta),-1*np.sin(theta)],[np.sin(theta), np.cos(theta)]])

            clPtA = np.matmul(R,clPtA)
            linePtA = np.matmul(R,linePtA)
            clPtB = np.matmul(R,clPtB)
            linePtB = np.matmul(R,linePtB)

            lineArrA = np.sort(np.array([clPtA,linePtA]),0)
            lineArrB = np.sort(np.array([clPtB,linePtB]),0)

            y1 = lineArrA[0,1]
            y2 = linePtA[1,1]
            y3 = lineArrB[0,1]
            y4 = lineArrB[1,1]

            if (y1 <= y3 and y3 <= y2) or (y1 <= y4 and y4 <= y2) or (y3<=y1 and y2<=y4) or (y1<=y3 and y4<=y2):
                D = abs(clPtA[0] - clPtB[0])
            elif y1>y4:
                D = np.linalg.norm(lineArrA[0,:] - lineArrB[1,:])
            else:
                D = np.linalg.norm(lineArrA[1,:] - lineArrB[0,:])

        else:

            lineIntersect = np.array([(interceptA - interceptB)/(mB - mA), mB*((interceptA - interceptB)/(mB - mA))+interceptB])

            endPtsA = np.array([clPtA,linePtA])
            endPtsB = np.array([clPtB,linePtB])

            endPA = min(np.linalg.norm(lineIntersect - clPtA), np.linalg.norm(lineIntersect-linePtA))
            endPB = min(np.linalg.norm(lineIntersect - clPtB), np.linalg.norm(lineIntersect-linePtB))

            D1 = np.abs(nB*endPtsA[endPA,0] - endPtsA[endPA,1] + interceptB)/np.sqrt(mB**2+1)
            D2 = np.abs(nA*endPtsB[endPB,0] - endPtsB[endPB,1] + interceptA)/np.sqrt(mA**2+1)

            if D1==0:
                D = D2
            elif D2 == 0:
                D = D1
            else:
                D = min(D1,D2)
    return D
