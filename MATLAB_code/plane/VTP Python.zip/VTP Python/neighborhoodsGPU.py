import numpy as np


def neighborhood(DT, r):
    indptr, indices = DT.vertex_neighbor_vertices
    points = DT.points
    N = (np.shape(points)[0])
    nbhd = [None]*N
    dist = [None]*N
    nearest = [None]*N
    for i in range(N):
        firstNbhd = indices[indptr[i]:indptr[i+1]]
        d = np.linalg.norm(points[firstNbhd,:] - points[i,:],2,axis=1)
        indMin = np.argmin(d)
        dist[i] = (d[indMin])
        nearest[i] = firstNbhd[indMin]
        secondNbhd = []
        if r != 1:
            for neighbor_idx in firstNbhd:
                neighbors_of_neighbor = indices[indptr[neighbor_idx]:indptr[neighbor_idx+1]]
                secondNbhd.append(neighbors_of_neighbor)
            secondNbhd = np.concatenate(secondNbhd)
            secondNbhd = np.reshape(secondNbhd,-1)
            secondNbhd = np.unique(secondNbhd)
            secondNbhd = secondNbhd[secondNbhd!=i]
        nbhd[i] = ((firstNbhd,secondNbhd))
    return nbhd,nearest,dist