import numpy as np
def polarization(U,Ndogs):
    with np.errstate(divide='ignore', invalid='ignore'):
        normedDisplacement = (U.T/np.linalg.norm(U,2,axis=1))
        normedDisplacement = np.nan_to_num(normedDisplacement)  # replace NaNs with 0

    Nsheep = np.size(U,0) - Ndogs
    normedDisplacement[np.isnan(normedDisplacement)] = 0
    added = np.sum(normedDisplacement[Ndogs:,:],axis=0)
    pol = np.linalg.norm(added,2,axis=0)
    return pol/Nsheep