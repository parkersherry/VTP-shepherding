import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay, ConvexHull
import awkward as ak
# Make sure your helper modules are available in Python
from alignToGPU import alignTo
from dogMovementScheme import dogMovementScheme
from LDOD_GPU import LDOD_gpu
import neighborhoods
from polarization import polarization
from sheepMovementSchemeGPU import sheepMovementScheme
from showAgents import showAgents
import Target
from voronoiProjectToBoundary import voronoiProjectToBoundary

#---------------------------
# Parameters
dt = 1/5
N = 35
alpha = np.inf
Ndogs = 1
L = 3/4
nu = np.ones(N)
tmax = 1000
pressures = np.zeros(tmax)
CMDrift = np.zeros(tmax)

vMaxSheep = 0.4800017685470678
HomingDistance = 10*L

# Random seeds
np.random.seed(10)

# Display options
display = True
fixframe = True
frameinrad = 30

fdim = 1
M0 = L
if fdim == 2:
    M0 = np.pi*L**2/2

#---------------------------
# Initial conditions
Nsheep = N - Ndogs
ic_radSheep = np.sqrt(Nsheep)*L
ic_radDog = np.sqrt(Ndogs)*L

X = np.zeros((N,2))
X[:Ndogs,:] = ic_radDog*(2*np.random.rand(Ndogs,2)-1) - np.sqrt(2*N)*L
X[Ndogs:,:] = ic_radSheep*(2*np.random.rand(Nsheep,2)-1)

angles = np.arctan2(X[Ndogs:,1], X[Ndogs:,0])
permutation = np.argsort(angles)
X[Ndogs:,:] = np.roll(X[Ndogs:,:][permutation,:], Nsheep, axis=0)

sheepThetaVision = ((np.pi/180)*(306-191))*np.random.rand(N) + (np.pi/180)*191

ang = 2*np.pi*np.random.rand(N)
U = np.column_stack((np.cos(ang), np.sin(ang)))
U[:Ndogs,:] = 0

X_0 = X.copy()

#---------------------------
# Initialize targets
tar = Target.Target([])
dogTar = Target.Target(np.array([20,20]))

#---------------------------
# Preallocation
r = np.zeros((N,2))
h = np.zeros((N,2))
U1 = np.zeros((N,2))
Q = np.zeros((N,2))
ldod1 = np.zeros(tmax)
U_t = np.zeros((N,2,tmax))
DT_t = [None]*tmax
X_T = np.zeros((N,2,tmax))
Polarization_t = np.zeros(tmax)
DistMatrixCell = [None]*tmax
equil = 0
muMixing = np.zeros(tmax)
expDecay = np.zeros((N,2))
g = np.ones(N)
sizeOfVel = np.linalg.norm(U, axis=1)
tooLarge = np.where(sizeOfVel>vMaxSheep)[0]
g[tooLarge] = vMaxSheep/sizeOfVel[tooLarge]
U[Ndogs:,:] = (g[Ndogs:None,None]*U[Ndogs:,:]).reshape(-1,2)

Xmem = np.zeros((N, 2))
LastSeen = np.zeros(N)

#---------------------------
# Time loop
for t in range(tmax):
    # Delaunay triangulation
    DT = Delaunay(X)
    hull = ConvexHull(X)
    nbhd, nearest, d = neighborhoods.neighborhood(DT,2)

    nbhd = ak.Array(nbhd)
    firstnbhd = nbhd["0"]
    sndnbhd = nbhd["1"]
    allnbhd = [None]*len(firstnbhd)
    for i in range(len(firstnbhd)):
        allnbhd[i] = np.unique(np.union1d(firstnbhd[i],sndnbhd[i]))

    ldod1[t] = LDOD_gpu(X[Ndogs:,:], 10*L)
    DT_t[t] = DT
    U_t[:,:,t] = U
    X_T[:,:,t] = X
    Polarization_t[t] = polarization(U, Ndogs)
    CMDrift[t] = np.linalg.norm(np.mean(X[Ndogs:,:]-np.array([20,20]),axis=0))

    # Alignment vector
    a = alignTo(X, U, allnbhd, 'sin', sheepThetaVision, Ndogs, vMaxSheep)

    # Preference field
    FourierCoeff = np.zeros((10,10,3))
    prefVel = np.zeros_like(X)

    # Dog movement dynamics
    if Ndogs>0:
        DMS = dogMovementScheme(X_T,U, DT, Ndogs, L, dogTar,t,dt,LastSeen,Xmem,240,allnbhd,nearest)
        U1 = DMS[0]
        equil = DMS[1]
        LastSeen = DMS[3]
        Xmem = DMS[4]
        expDecay = DMS[5]
    else:
        # fallback
        U1 = U.copy()

    # Sheep movement
    C = sheepMovementScheme(X, U1, DT, L, Ndogs, 'expReciprocal','dogexpReciprocal',firstnbhd, tar, HomingDistance)
    r, h = C

    # Update velocities
    U1[Ndogs:,:] = (r[Ndogs:,:] + h[Ndogs:,:] + nu[Ndogs:None,None]*a[Ndogs:,:])/(1 + nu[Ndogs:None,None]).reshape(-1,1)

    # Voronoi projection (sheep density)
    _, l,_ = voronoiProjectToBoundary(DT,U1)
    M = l
    if fdim==2:
        from voronoiForwardArea import voronoiForwardArea
        M = voronoiForwardArea(DT,U1)

    # Enforce max sheep speed
    g = np.ones(N)
    sizeOfVel = np.linalg.norm(U1, axis=1)
    tooLarge = np.where(sizeOfVel>vMaxSheep)[0]
    g[tooLarge] = vMaxSheep/sizeOfVel[tooLarge]
    U1[Ndogs:,:] = (g[Ndogs:None,None]*U1[Ndogs:,:]).reshape(-1,2)

    # Update positions
    X = X + U1*dt
    U = U1.copy()

    if display:
        showAgents(X, U, tar, DT, fixframe, Ndogs,
                   frameinrad, t, equil,Xmem, False, expDecay)

#---------------------------
# Save results
np.savez("data.npz", ldod=ldod1)
