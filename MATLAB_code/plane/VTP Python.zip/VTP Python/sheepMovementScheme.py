import numpy as np
import goToCM
import transition
import neighborhoods
import Target

def sheepMovementScheme(X, U, DT, L, Ndogs, transition_func, dog_trans_func, Firstnbhd, tar, HomingDistance=None):
    nbhd, nearest, d = neighborhoods.neighborhood(DT,2)
    N = X.shape[0]
    if HomingDistance is None:
        HomingDistance = 1000*L
    # Scalar functions
    def fun(x):
        return transition.transition(x, transition_func)
    def funDog(x):
        return transition.transition(x, dog_trans_func)

    ##TODO: CHECK ABOUT DOGL

    dogL = 5*L
    LArrRepulsion = L*np.ones(N)
    LArrAttractionToCM = L*np.ones(N)
    ToCMStrength = np.ones(N)

    nearest = np.array(nearest)
    nearestIsDog = nearest >= Ndogs

    # Agent-agent repulsion
    r = X - X[nearest,:]
    rnorm = np.linalg.norm(r, axis=1, keepdims=True)
    r = np.divide(r, rnorm, out=np.zeros_like(r), where=rnorm!=0)

    # Initialize dog repulsion
    rToDog = np.zeros_like(X)

    for j in range(Ndogs,N):
        allNbhd = np.unique(np.concatenate([nbhd[j][0], nbhd[j][1]]))
        strengthenToCM = True
        for neighbor in allNbhd:
            if neighbor < Ndogs:   # neighbor is a dog
                vec = X[j,:] - X[neighbor,:]
                vecNorm = np.linalg.norm(vec)
                dogVelNorm = np.linalg.norm(U[neighbor,:])
                cosTheta = 0
                if vecNorm != 0 and dogVelNorm != 0:
                    cosTheta = np.dot(vec/vecNorm, U[neighbor,:]/dogVelNorm)
                    cosTheta = max(cosTheta, 0)
                sDog = funDog(vecNorm/dogL)
                if vecNorm != 0:
                    rToDog[j,:] += 0.5*(1+cosTheta)*sDog*vec/vecNorm
                # strengthen attraction to CM for first dog neighbor
                if strengthenToCM:
                    ##TODO: THESE
                    LArrAttractionToCM[j] /= 5
                    ToCMStrength[j] = 5
                    strengthenToCM = False

    # Sheep-sheep repulsion
    s = np.array([fun(d[i]/LArrRepulsion[i]) for i in range(N)])
    r = r * s[:, np.newaxis]
    # Attraction to center of mass
    toCM = ToCMStrength[:, np.newaxis] * goToCM.goToCM(X, Firstnbhd, N, Ndogs, 'linear2', LArrAttractionToCM, L,HomingDistance)
    # Ignore flock repulsion if dog is nearest neighbor
    r = r * nearestIsDog[:, np.newaxis]

    # Combine influences
    r = r + rToDog + toCM

    # Homing vector
    h0 = Target.homeToTarget(tar, X)
    hNorm = np.linalg.norm(h0, axis=1)
    mask = hNorm > HomingDistance
    h0[mask,:] = 0
    hNorm[mask] = 0
    h = np.zeros_like(h0)
    with np.errstate(divide='ignore', invalid='ignore'):
        h = ((1 - np.abs(s))[:, np.newaxis] * h0 / hNorm[:, np.newaxis])
        h[np.isnan(h)] = 0

    return r, h
