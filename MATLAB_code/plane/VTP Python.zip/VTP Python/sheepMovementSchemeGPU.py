import numpy as np
import goToCMGPU
import transition
import neighborhoods
import Target

def sheepMovementScheme(X, U, DT, L, Ndogs, transition_func, dog_trans_func, Firstnbhd, tar, HomingDistance=None):
    X = np.asarray(X)
    U = np.asarray(U)
    N = X.shape[0]

    if HomingDistance is None:
        HomingDistance = 1000 * L

    strengthening = 1

    dogL = 5 * L
    LArrRepulsion = np.full(N, L)
    LArrAttractionToCM = np.full(N, L)
    ToCMStrength = np.ones(N)

    # Neighborhood info
    nbhd, nearest, d = neighborhoods.neighborhood(DT, 2)
    nearest = np.asarray(nearest)
    nearestIsDog = nearest >= Ndogs

    # Vectorized sheep-sheep repulsion
    r = X - X[nearest, :]
    rnorm = np.linalg.norm(r, axis=1, keepdims=True)
    r = np.divide(r, rnorm, out=np.zeros_like(r), where=rnorm!=0)
    def fun(x):
        return transition.transition(x,transition_func)
    ratioDist = d/LArrRepulsion
    s = np.zeros_like(d)
    #can this be made faster/vectorized?
    for i in range(N):
        s[i] = fun(ratioDist[i])
    r = r * s[:, np.newaxis]

    # ----------------------
    # Dog-sheep interactions
    # Only loop over dogs (fewer than sheep)
    rToDog = np.zeros_like(X)
    for dog in range(Ndogs):
        # Find all sheep neighbors of this dog
        neighbors = np.unique(np.concatenate([np.asarray(nbhd[dog][0]), np.asarray(nbhd[dog][1])]))
        sheep_neighbors = neighbors[neighbors >= Ndogs]  # only sheep
        if sheep_neighbors.size == 0:
            continue

        vec = X[sheep_neighbors, :] - X[dog, np.newaxis, :]  # vector from dog to sheep
        vecNorm = np.linalg.norm(vec, axis=1, keepdims=True)
        dogVelNorm = np.linalg.norm(U[dog, :])
        cosTheta = np.where((vecNorm != 0) & (dogVelNorm != 0),
                            np.clip(np.sum(vec * U[dog, :] / dogVelNorm, axis=1, keepdims=True) / vecNorm, 0, None),
                            0)
        sDog = np.array([transition.transition(val / dogL, dog_trans_func) for val in vecNorm.flatten()]).reshape(-1, 1)
        rToDog[sheep_neighbors, :] += 0.5 * (1 + cosTheta) * sDog * np.divide(vec, np.where(vecNorm==0, 1, vecNorm))

        LArrAttractionToCM[sheep_neighbors] = L/strengthening
        ToCMStrength[sheep_neighbors] = strengthening

    # Ignore flock repulsion if dog is nearest neighbor
    r = r * nearestIsDog[:, np.newaxis]
    # Attraction to center of mass
    toCM = ToCMStrength[:, np.newaxis] * np.asarray(
        goToCMGPU.goToCM((X), Firstnbhd, N, Ndogs, 'linear2', (LArrAttractionToCM), L, HomingDistance)
    )
    # Combine all influences
    r_total = r + rToDog + toCM

    # Homing vector
    h0 = np.asarray(Target.homeToTarget(tar, (X)))
    hNorm = np.linalg.norm(h0, axis=1)
    mask = hNorm > HomingDistance
    h0[mask, :] = 0
    hNorm[mask] = 0

    with np.errstate(divide='ignore', invalid='ignore'):
        h = ((1 - np.abs(s))[:, np.newaxis] * h0 / hNorm[:, np.newaxis])
        h = np.nan_to_num(h)

    return (r_total), (h)
