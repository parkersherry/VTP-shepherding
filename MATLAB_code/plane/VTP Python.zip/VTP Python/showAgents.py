# showAgents.py
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection

# Optional: for shapely polygons, if user uses shapely for target components
try:
    from shapely.geometry import Polygon as ShapelyPolygon
    HAS_SHAPELY = True
except Exception:
    HAS_SHAPELY = False


def showAgents(X, U, tar, DT, fixframe, Ndogs, frameinrad, t, equilibrium,
               timeStratifiedX, plotTSX, expDecay):
    """
    Python version of the MATLAB showAgents plotting routine.

    Parameters
    ----------
    X : (N,2) array
        Positions.
    U : (N,2) array
        Unit/velocity vectors.
    tar : object
        Target object with attribute `Components` (iterable). Each component
        may be:
          - a numpy array (M,2) of polygon vertices -> will be plotted as filled polygon
          - an object with a `plot(ax)` method -> that method will be invoked
          - (optionally) a shapely Polygon -> will be drawn
    DT : unused placeholder (kept for signature parity)
    fixframe : bool
        If True, uses the provided frame; otherwise auto-centers on data.
    Ndogs : int
        Number of dogs (first Ndogs entries in X).
    frameinrad : float
        Default frame radius when fixframe is True.
    t : int
        Current time step (used in title).
    equilibrium : array-like (2,) or sequence
        Plot dog equilibrium as a green marker if Ndogs>0.
    alphaHull : unused placeholder (kept for signature parity)
    timeStratifiedX : list or ndarray
        If plotTSX True, used to plot past positions with alpha scaled by expDecay.
    plotTSX : bool
        Whether to show time-stratified X memory.
    expDecay : array-like of alpha weights (same length as timeStratifiedX)
    colours : array-like or sequence
        Colors for subflocks (passed to scatter).
    pallette : matplotlib colormap name or array
        Colormap for scatter/contours.
    scalarField : str
        Name of scalar field; 'zero' disables plotting.
    subflocksCell : list of (M,2) arrays
        Each subflock is plotted as a group.
    """
    purple = np.array([128, 0, 128]) / 255.0
    clipToVoronoi = False

    # Create / select figure 1
    fig = plt.figure(1)
    ax = plt.gca()
    ax.clear()

    # Plot dogs (first Ndogs) in blue
    if Ndogs > 0:
        if Ndogs <= X.shape[0]:
            ax.scatter(X[:Ndogs, 0], X[:Ndogs, 1], c='blue', s=36, label='dogs', zorder=4)

    # Plot time-stratified memory points if requested
    if plotTSX and (timeStratifiedX is not None):
        tsx = np.asarray(timeStratifiedX).copy()
        # Remove empty rows (rows where all values are zero or nan)
        if tsx.ndim == 2 and tsx.size > 0:
            # remove rows that are all zeros (mimic MATLAB `find(~any(timeStratifiedX'))`)
            valid_rows = np.any(~np.isnan(tsx), axis=1) & (np.any(tsx != 0, axis=1))
            tsx = tsx[valid_rows, :]
            if tsx.size > 0:
                # expDecay must align with tsx; try to broadcast
                expDecay_arr = np.asarray(expDecay).ravel()
                if expDecay_arr.size != tsx.shape[0]:
                    # try repeat or trim accordingly
                    if expDecay_arr.size == 1:
                        expDecay_arr = np.repeat(expDecay_arr, tsx.shape[0])
                    else:
                        # trim or pad
                        L = min(expDecay_arr.size, tsx.shape[0])
                        expDecay_arr = np.concatenate([expDecay_arr[:L], np.zeros(tsx.shape[0]-L)])
                sc = ax.scatter(tsx[:, 0], tsx[:, 1], s=40, c='cyan', marker='s', zorder=2)
                # Marker alpha cannot be set per-point directly for older mpl versions,
                # so use the returned PathCollection's set_alpha if flat or use arrays:
                sc.set_alpha(None)
                # We'll set facecolors with alpha per point:
                fc = sc.get_facecolors()
                if fc.shape[0] >= tsx.shape[0]:
                    # adjust alpha
                    for ii in range(tsx.shape[0]):
                        fc[ii, -1] = np.clip(5.0 * expDecay_arr[ii], 0, 1.0)
                    sc.set_facecolors(fc)

                # Plot weighted centroid if meaningful
                denom = np.sum(expDecay_arr)
                if denom > 0:
                    CM = np.sum((expDecay_arr[:, None] * tsx), axis=0) / denom
                    ax.scatter(CM[0], CM[1], c='red', marker='s', zorder=5)


    # Plot dog equilibrium (single green point)
    if Ndogs > 0 and equilibrium is not None:
        eqpt = np.asarray(equilibrium).ravel()
        if eqpt.size >= 2:
            ax.scatter(eqpt[0], eqpt[1], c='green', marker='o', zorder=6)

    # Draw arrows for velocities (quiver). scale factor roughly equals MATLAB's qs=0.5
    qs = 0.5
    try:
        ax.quiver(X[:, 0], X[:, 1], qs * U[:, 0], qs * U[:, 1], angles='xy', scale_units='xy', scale=1, color='k', zorder=1)
    except Exception:
        pass

    # Plot targets: tar.Components expected to be iterable
    try:
        C = getattr(tar, 'Components', None)
        if C is not None:
            for comp in C:
                # If comp is a numpy array of polygon points, plot filled polygon:
                if isinstance(comp, (np.ndarray, list, tuple)):
                    comp_arr = np.asarray(comp)
                    if comp_arr.ndim == 2 and comp_arr.shape[1] >= 2 and comp_arr.shape[0] > 2:
                        poly = Polygon(comp_arr[:, :2], closed=True)
                        ax.add_patch(poly)
                        poly.set_facecolor('none')
                        poly.set_edgecolor('black')
                else:
                    # shapely polygon
                    if HAS_SHAPELY and isinstance(comp, ShapelyPolygon):
                        xs, ys = comp.exterior.xy
                        ax.fill(xs, ys, edgecolor='black', facecolor='none')
                    else:
                        # fallback: if object has plot(ax=...), call it
                        try:
                            comp.plot(ax=ax)
                        except Exception:
                            pass
    except Exception:
        pass

    # Determine clip (plot limits)
    clip_min = np.min(X, axis=0)
    clip_max = np.max(X, axis=0)
    if clipToVoronoi and DT is not None:
        try:
            # If DT is a scipy Delaunay object, we can build Voronoi via scipy.spatial.Voronoi
            from scipy.spatial import Voronoi
            vor = Voronoi(X)
            V = vor.vertices
            all_pts = np.vstack([V, X])
            clip_min = np.min(all_pts, axis=0)
            clip_max = np.max(all_pts, axis=0)
        except Exception:
            pass

    clip_width = 1.2 * np.max(clip_max - clip_min)
    clip_center = 0.5 * (clip_max + clip_min)
    # compute frame: [xmin, xmax, ymin, ymax]
    if not fixframe:
        com = np.mean(X, axis=0)
        rmed = np.sqrt(np.median((X[:, 0] - com[0])**2 + (X[:, 1] - com[1])**2))
        frame = [com[0] - 3 * rmed, com[0] + 3 * rmed, com[1] - 3 * rmed, com[1] + 3 * rmed]
    else:
        frame = [-frameinrad, frameinrad, -frameinrad, frameinrad]

    ax.set_aspect('equal', adjustable='box')
    ax.set_xlim(frame[0], frame[1])
    ax.set_ylim(frame[2], frame[3])

    # Scalar preference field / contours (if scalarField != 'zero')

    ax.set_title(f'$t={t}$', fontsize=12)
    # show legend optional
    # ax.legend()
    plt.draw()
    plt.pause(0.001)
    # no meaningful return value
    return None
