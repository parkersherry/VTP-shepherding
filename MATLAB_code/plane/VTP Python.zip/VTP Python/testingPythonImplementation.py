import numpy as np
import scipy
import matplotlib.pyplot as plt
import neighborhoods
import neighborhoodsGPU

X = np.random.rand(20,2)
DT = scipy.spatial.Delaunay(X)
nbhdCPU,nearestCPU,dCPU = neighborhoods.neighborhood(DT,2)
nbhdGPU,nearestGPU,dGPU = neighborhoodsGPU.neighborhood(DT,2)

print(nbhdGPU)
print(nbhdCPU)
