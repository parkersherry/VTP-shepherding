import numpy as np


class NoSuchTransition(Exception):
    """Exception raised for insufficient funds in an account."""
    def __init__(self, message="There is no function associated with this input"):
        self.message = message
        super().__init__(self.message)
def transition(x,spec):
    if (x>=1 and spec!='linear2'):
        y=0
    else:
        match spec:
            case 'indicator':
                y = 1
            case 'sin':
                y = np.sin(np.pi*x)
            case 'mollifier':
                y = np.exp(1-1/(1-x**2))
            case 'cubic':
                y = 2*x**3 - 3*x**2 + 1
            case 'linear':
                y = 1-x
            case 'linear2':
                y = x*x
            case 'expReciprocal':
                y = np.exp(-1/(1-x)) / (np.exp(-1/x)+np.exp(-1/(1-x)))
            # case 'attractionexp':
            #     y = piecewise((0 < z) && (z < 0.5), np.exp(-1/(1-2*z)) / (np.exp(-1/(2*z))+np.exp(-1/(1-2*z))), (0.5 < z) && (z < 1), np.exp(-1/(1-(2*z-1))) / (np.exp(-1/(2*z-1))+np.exp(-1/(1-(2*z-1))))-1)
            #     subs(y,z,x)
            case 'attractionSub':
                y = (1+1)*(np.exp(-1/(1-x)) / (np.exp(-1/x)+np.exp(-1/(1-x))))-1
            case 'attractionSubAlign':
                y = 1- abs(2*(np.exp(-1/(1-x)) / (np.exp(-1/x)+np.exp(-1/(1-x))))-1)
            case 'dogexpReciprocal':
                y = np.exp(-1/(1-x)) / (np.exp(-1/x)+np.exp(-1/(1-x)))
            case _:
                raise NoSuchTransition
    return y