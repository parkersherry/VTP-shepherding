import numpy as np
from scipy.spatial import Delaunay
import voronoiProjectToBoundary
# Make sure to have your GPU-compatible voronoiProjectToBoundary version ready

def poly_area(x, y):
    """Compute polygon area using the shoelace formula (on GPU)."""
    return 0.5 * np.abs(np.sum(x[:-1]*y[1:] - x[1:]*y[:-1]))

def voronoiForwardArea(DT, U):
    """
    GPU-optimized Python version of MATLAB voronoiForwardArea.
    Inputs:
        DT : scipy.spatial.Delaunay object
        U  : Nx2 array of unit vectors
    Outputs:
        A     : N-length array of forward-projected areas
        verts : list of N arrays (vertices of projected polygons)
    """
    # Move data to GPU
    X = np.array(DT.points)
    U = np.array(U)
    N = U.shape[0]

    verts = [None]*N
    A = np.full(N, np.inf)

    # Rotate directions
    Ul = np.stack([-U[:,1], U[:,0]], axis=1)
    Ur = np.stack([U[:,1]*-1 + 0*U[:,0], -U[:,0]], axis=1)  # simplified for clockwise rotation
    Ql, _, _ = voronoiProjectToBoundary(DT, Ul)  # ensure this returns GPU arrays
    Qr, _, _ = voronoiProjectToBoundary(DT, Ur)

    # Identify infinite projections
    infArea = (np.isinf(Ql[:,0])) | (np.isinf(Qr[:,0]))

    # Voronoi diagram vertices and regions
    vor = DT.voronoi()  # or your GPU-compatible voronoi wrapper
    V = np.array(vor.vertices)
    C = vor.point_region  # list of indices into V

    al = np.arctan2(Ql[:,1]-X[:,1], Ql[:,0]-X[:,0])
    ar = np.arctan2(Qr[:,1]-X[:,1], Qr[:,0]-X[:,0])

    # Convex hull and boundary edges
    hull = np.array(DT.convex_hull)
    CH = hull.flatten()
    IN = np.setdiff1d(np.arange(N), CH)

    # Unbounded edge angles (like MATLAB freeBoundary)
    X_bd = X[CH[:-1]]
    d = np.roll(X_bd, -1, axis=0) - X_bd
    unbd_edge_arg = np.arctan2(d[:,1], d[:,0]) - np.pi/2
    unbd_edge_arg = unbd_edge_arg + 2*np.pi*(unbd_edge_arg < -np.pi)

    # --- Interior generators ---
    for i in IN:
        v = V[C[i],:]
        numverts = v.shape[0]
        a = np.arctan2(v[:,1]-X[i,1], v[:,0]-X[i,0])
        S = np.argsort(np.concatenate([a, np.array([al[i], ar[i]])]))
        S = np.roll(S, 1 - np.where(S==numverts+1)[0][0])
        k = int(np.where(S==numverts)[0][0])
        P = np.vstack([Qr[i,:], v[S[1:k-1],:], Ql[i,:]])
        verts[i] = P
        A[i] = poly_area(P[:,0], P[:,1])

    # --- Boundary generators ---
    m = len(CH)-1
    for l in range(m):
        i = CH[l]
        if infArea[i]:
            continue
        v = V[C[i],:]
        numverts = v.shape[0]-1
        a = np.zeros(numverts+2)
        a[0] = unbd_edge_arg[l]
        a[1:-1] = np.arctan2(v[1:,1]-X[i,1], v[1:,0]-X[i,0])
        a[-1] = unbd_edge_arg[(l-1 + m*(l==0))%m]
        S = np.argsort(np.concatenate([a, np.array([al[i], ar[i]])]))
        S = np.roll(S, 1 - np.where(S==numverts+3)[0][0])
        k = int(np.where(S==numverts+2)[0][0])
        kin = int(np.where(S==0)[0][0])
        kout = int(np.where(S==numverts+1)[0][0])
        if kin < k or kout < k:
            continue
        P = np.vstack([Qr[i,:], v[S[1:k-1],:], Ql[i,:]])
        verts[i] = P
        A[i] = poly_area(P[:,0], P[:,1])

    return A, verts
