import scipy
import numpy as np
def voronoiPressure(DT):
    P = 0
    X = DT.points
    VT = scipy.spatial.Voronoi(X)
    V = VT.vertices
    C = VT.regions
    N = np.size(X,0)
    for region_index in VT.point_region:
        if region_index!= -1 and -1 not in C[region_index]:
            verts = V[C[region_index]]
            hull = scipy.spatial.ConvexHull(verts)
            A = hull.volume
            P += 1/A
    return P/N