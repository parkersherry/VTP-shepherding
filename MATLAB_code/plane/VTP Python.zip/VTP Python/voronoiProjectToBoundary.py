import numpy as np
from scipy.spatial import Voronoi, Delaunay, ConvexHull
from shapely.geometry import LineString


def polyxpoly_shapely(x1, y1, x2, y2):
    line1 = LineString(list(zip(x1, y1)))
    line2 = LineString(list(zip(x2, y2)))
    inter = line1.intersection(line2)
    if inter.is_empty:
        return np.array([]), np.array([])
    if inter.geom_type == 'Point':
        return np.array([inter.x]), np.array([inter.y])
    elif inter.geom_type == 'MultiPoint':
        pts = np.array([[p.x, p.y] for p in inter.geoms])
        return pts[:,0], pts[:,1]
    elif inter.geom_type in ('LineString', 'MultiLineString'):
        coords = []
        if inter.geom_type == 'LineString':
            coords.extend(list(inter.coords))
        else:
            for line in inter.geoms:
                coords.extend(list(line.coords))
        coords = np.unique(coords, axis=0)
        return coords[:,0], coords[:,1]
    else:
        return np.array([]), np.array([])


def voronoiProjectToBoundary(DT, U):
    X = DT.points
    N = X.shape[0]
    Q = np.zeros((N,2))
    r = np.zeros(N)


    vor = Voronoi(X)
    V = vor.vertices


    # Convex hull for boundary detection
    hull = ConvexHull(X)
    CH = np.append(hull.vertices, hull.vertices[0])


    # Unbounded edge directions for convex hull edges
    X_bd = X[CH[:-1]]
    d = np.roll(X_bd, -1, axis=0) - X_bd
    unbd_edge_arg = np.arctan2(d[:,1], d[:,0]) - np.pi/2
    unbd_edge_arg[unbd_edge_arg < -np.pi] += 2*np.pi


    # Voronoi cells
    C = []
    for reg_index in vor.point_region:
        verts = vor.regions[reg_index]
        if len(verts)==0:
            C.append([])
        else:
            C.append(verts)


    # Bounds and L for rays
    bounds = np.vstack([V, X])
    L = 2*((bounds.max(axis=0)-bounds.min(axis=0)).sum())


    # --- Interior generators ---
    IN = np.setdiff1d(np.arange(N), CH)
    for i in IN:
        a = np.arctan2(U[i,1], U[i,0])
        rayx = [X[i,0], X[i,0]+L*np.cos(a)]
        rayy = [X[i,1], X[i,1]+L*np.sin(a)]


        verts_idx = [v for v in C[i] if v != -1]
        if len(verts_idx) < 3:
            Q[i,:] = np.inf
            r[i] = np.inf
            continue


        verts = np.array([V[v] for v in verts_idx])


        # Ensure CCW order around generator
        center = verts.mean(axis=0)
        ang = np.arctan2(verts[:,1]-X[i,1], verts[:,0]-X[i,0])
        verts = verts[np.argsort(ang)]


        verts_close = np.vstack([verts, verts[0]])
        xi, yi = polyxpoly_shapely(rayx, rayy, verts_close[:,0], verts_close[:,1])
        if xi.size == 0:
            Q[i,:] = np.inf
            r[i] = np.inf
        else:
            idx = np.argmin(np.sqrt((xi - X[i,0])**2 + (yi - X[i,1])**2))
            Q[i,:] = [xi[idx], yi[idx]]
            r[i] = np.linalg.norm(Q[i]-X[i])


    # --- Boundary generators ---
    m = len(CH)-1
    E = np.zeros((m,3))
    for l in range(m):
        i = CH[l]
        verts_idx = [v for v in C[i] if v != -1]
        a = np.arctan2(U[i,1], U[i,0])


        if len(verts_idx) < 2:
            Q[i,:] = np.inf
            r[i] = np.inf
            continue


        verts = np.array([V[v] for v in verts_idx])


        # CCW order around generator
        ang = np.arctan2(verts[:,1]-X[i,1], verts[:,0]-X[i,0])
        verts = verts[np.argsort(ang)]
        numverts = verts.shape[0]


        # Angles of edges
        a1 = unbd_edge_arg[l]             # clockwise-out unbounded
        a2 = np.arctan2(verts[1,1]-X[i,1], verts[1,0]-X[i,0])
        a3 = np.arctan2(verts[-1,1]-X[i,1], verts[-1,0]-X[i,0])
        a4 = unbd_edge_arg[(l-1 + m*(l==0)) % m]  # counterclockwise-out unbounded


        angles = np.hstack(([a], [a1], a2, a3, [a4]))
        S = np.argsort(angles)
        S = np.roll(S, -np.where(S==0)[0][0])
        case_idx = S[1]


        if case_idx == 1:
            xi, yi = np.inf, np.inf
        elif case_idx == 2:
            p = verts[1]
            d_vec = p - X[i]
            denom = np.sin(a - a1)
            if abs(denom)<1e-12:
                xi, yi = np.inf, np.inf
            else:
                t = -np.linalg.norm(d_vec)*np.sin(a - np.arctan2(d_vec[1],d_vec[0]))/denom
                xi = p[0] + t*np.cos(a1)
                yi = p[1] + t*np.sin(a1)
        elif case_idx == 3:
            rayx = [X[i,0], X[i,0]+L*np.cos(a)]
            rayy = [X[i,1], X[i,1]+L*np.sin(a)]
            verts_close = np.vstack([verts[1:], verts[1]])
            xi, yi = polyxpoly_shapely(rayx, rayy, verts_close[:,0], verts_close[:,1])
            if xi.size==0:
                xi, yi = np.inf, np.inf
            else:
                idx = np.argmin(np.sqrt((xi - X[i,0])**2 + (yi - X[i,1])**2))
                xi, yi = xi[idx], yi[idx]
        elif case_idx == 4:
            p = verts[-1]
            d_vec = p - X[i]
            denom = np.sin(a - a4)
            if abs(denom)<1e-12:
                xi, yi = np.inf, np.inf
            else:
                t = -np.linalg.norm(d_vec)*np.sin(a - np.arctan2(d_vec[1],d_vec[0]))/denom
                xi = p[0] + t*np.cos(a4)
                yi = p[1] + t*np.sin(a4)
        else:
            xi, yi = np.inf, np.inf


        Q[i,:] = [xi, yi]
        r[i] = np.linalg.norm(Q[i]-X[i])
        E[l,:] = [verts[1,0], verts[1,1], a1]


    return Q, r, E